#include "VendingMachine.h"
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

int main()
{
	string action, entry;
	double cash;
	string filename = "C:/temp/Adriel.txt";
	ifstream in;
	in.open(filename);


	VendingMachine vm;
	/*vm.PushButton("D4");
	vm.InsertCash(1.50);
	vm.PushButton("D6");
	vm.swipeCard("VISA");
	vm.PushButton("D4");
	vm.swipeCard("AMX");
	vm.PushButton("D4");
	vm.InsertCash(0.70);
	vm.CancelOrder();*/

	while (!in.eof())
	{

		in >> action;
		in >> entry;
		if (action == "PressButton")
		{
			if (entry == "Cancel")
			{
				vm.CancelOrder();
			}
			else
			{
				vm.PushButton(entry);
			}
		}
		else if (action == "Swipe")
		{
			vm.swipeCard(entry);
		}
		else
		{
			cash = stod(entry);
			vm.InsertCash(cash);
		}

	}



	int i;
	cin >> i;
	return 0;

}