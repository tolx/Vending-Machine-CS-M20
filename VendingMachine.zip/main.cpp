#include "VendingMachine.h"
#include <iostream>
using namespace std;

int main()
{

	VendingMachine vm;
	vm.PushButton("D4");
	vm.InsertCash(1.50);
	vm.PushButton("D6");
	vm.swipCard("VISA");
	vm.PushButton("D4");
	vm.swipCard("AMX");
	vm.PushButton("D4");
	vm.InsertCash(0.70);
	vm.CancelOrder();



	int i;
	cin >> i;
	return 0;

}